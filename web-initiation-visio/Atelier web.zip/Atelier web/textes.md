# Navigation
- Découvrez notre libraire
- Notre actualité
- Conseils de lecture

# Librairie Clapet
## neuf & occasion

À deux pas de la Gare et à la frontière de Moulins, Clapet est une librairie de quartier, généraliste, dans laquelle vous trouverez des ouvrages jeunesse, BD, littérature, jeux/jouets et loisirs créatifs. Tenue par deux amies, elle se revendique librairie enthousiaste et familiale !

## Conseils de lecture

### Les grandes marées
De Jim Lynch

### Cette nuit
De Joachim Schnerf

## L’âge d’or
De Cyril Pedrosa

## Notre actualité

### Rencontre avec Tiffany Tavernier
5 Juin 2018
La rencontre est organisée dans le cadre du partenariat entre l'association Libr'aire et le Rectorat de Lille pour la première mise en place dans l'académie du Prix Femina des lycéens.

### Lecture d'extraits du roman "Roulio fauche le poil"
5 Juin 2018
Nous organisons une mise en voix du roman "Roulio fauche le poil" (de Julia, paru aux éditions Le Tripode) par un comédien et une comédienne.

### Dédicaces avec Marguerite Abouet & Mathieu Sapin
5 Juin 2018
A l'occasion de la parution du dernier tome de la série Akissi, Nous avons le plaisir de recevoir Marguerite Abouet et Mathieu Sapin pour une séance de dédicaces !



### Lecture - goûter avec Coline !
5 Juin 2018
Nous vous proposons une lecture- goûter animée par Coline ! Une lecture qui s'adresse aux enfants âgés de 3 à 6 ans. Le nombre de places est limité à 10 enfants, pensez à réserver.
