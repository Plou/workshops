# Categories

- Dumplings & Bao
  A category of food that can be generalized as delicious fillings wrapped in warm carbs, dumplings and bao. These recipes run the spectrum, from nostalgic steamed pork bao that takes me to my grandma's small kitchen in Memphis to pork shumai in creamy corn broth dedicated to my upbringing in the Midwest. These recipes are the perfect activity with friends and family, a ritual that covers you in flour and reminds you of home. 
- Bing
  Flatbreads or bing (餅), a comforting staple of many Taiwanese and Asian American households . Bing is a category of food that worth all the calories, it's layers can be filled with scallions and pan-fried for classic scallion pancakes. You can also make bing as a canvas for toppings, from scrambled egg to savory marinated meats like tender beef or pork. 
- Rice
- Noodles
  Noodles, the perfect vehicle for sauces or swimming in a bath of warm flavorful broth. The ideal landing pad for heaps of savory meats and stir-fried vegetables. You'll be able to find recipes to make the perfect homemade noodles here, or use these recipes to find the perfect combination of ingredients, whether that's sauce, soups, or toppings, to eat noodles with.
- Desserts 
  Desserts!