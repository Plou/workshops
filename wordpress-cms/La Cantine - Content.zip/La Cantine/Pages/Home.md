# BIENVENUE À LA CANTINE

On se crée des souvenirs, on invente des projets, on s’engage. Tout le monde a sa place, tout le monde a sa voix.

*cta*: Notre histoire


## Call to Action
### Le food court
Vous régale de cuisines et d’animations culturelles variées
- Ses corners
- Sa grande salle centrale
- Ses terrasses estivales
*cta*: Infos pratiques

### La cuisine
Cuisiner ensemble et se retrouver autour d’un repas animé
- Un lieu solidaire
- Au sein d’un espace de 200 m²
- Une douzaine d’ateliers par semaine
*cta*: Les ateliers

### La Ferme Urbaine
- Un espace expérimental
- Méthodes traditionnelles et innovations
- Coopérative et pédagogique
*cta*: En savoir plus


## Découvrez nos meilleurs recettes !
Retrouvez les plats les plus marquants de nos ateliers
*cta*: Les recettes